const express = require('express');
const router = express.Router();
const LinkedDuty = require('../models/LinkedDuty'); // your Mongoose model

// GET all linked duties
router.get('/all', async (req, res) => {
  try {
    const duties = await LinkedDuty.find();
    res.json(duties);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST add new linked duty
router.post('/add', async (req, res) => {
  try {
    const { busNo, driverName, routeNo, from, to } = req.body;

    if (!busNo || !driverName || !routeNo || !from || !to) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const linkedDuty = new LinkedDuty({
      busNo,
      driverName,
      routeNo,
      from,
      to,
    });

    await linkedDuty.save();
    res.status(201).json({ message: 'Linked duty added successfully', linkedDuty });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
