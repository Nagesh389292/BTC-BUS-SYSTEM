const express = require('express');
const router = express.Router();
const LinkedDuty = require('../models/LinkedDuty');

// GET all active bus locations
router.get('/buses', async (req, res) => {
  try {
    const buses = await LinkedDuty.find({}, 'busNo driverName currentLat currentLng');
    res.json(buses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;