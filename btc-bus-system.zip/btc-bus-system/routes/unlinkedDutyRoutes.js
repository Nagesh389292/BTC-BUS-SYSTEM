const express = require('express');
const router = express.Router();
const UnlinkedDuty = require('../models/UnlinkedDuty');
const LinkedDuty = require('../models/LinkedDuty');

// POST /api/unlinked-duty/unlink
router.post('/unlink', async (req, res) => {
  const { driverName, busNo, routeNo, from, to } = req.body;

  try {
    const existing = await LinkedDuty.findOneAndDelete({ driverName, busNo, routeNo, from, to });

    if (!existing) {
      return res.status(404).json({ message: 'No matching linked duty found.' });
    }

    const newUnlinked = new UnlinkedDuty({ driverName, busNo, routeNo, from, to });
    await newUnlinked.save();

    res.json({ success: true, message: 'Unlinked successfully.', data: newUnlinked });
  } catch (err) {
    console.error('Unlinking error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/all', async (req, res) => {
  try {
    const all = await UnlinkedDuty.find();
    res.json(all);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching unlinked duties' });
  }
});

module.exports = router;
