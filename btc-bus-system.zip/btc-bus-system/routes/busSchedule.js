// routes/busSchedule.js
const express = require('express');
const router = express.Router();

router.get('/:from/:to', (req, res) => {
  const { from, to } = req.params;

  // Simulated schedule data
  const schedule = [
    { stop: "Majestic", time: "10:00 AM" },
    { stop: "MG Road", time: "10:10 AM" },
    { stop: "Indiranagar", time: "10:20 AM" },
    { stop: "Whitefield", time: "10:40 AM" },
  ];

  res.json({ from, to, schedule });
});

module.exports = router;
