// routes/tripPlannerRoutes.js
const express = require('express');
const router = express.Router();
const LinkedDuty = require('../models/LinkedDuty');

router.post('/find-buses', async (req, res) => {
  const { from, to } = req.body;

  try {
    const buses = await LinkedDuty.find({ from, to });
    res.json(buses);
  } catch (err) {
    console.error('Error finding buses:', err);
    res.status(500).json({ error: 'Failed to find buses' });
  }
});

module.exports = router;
