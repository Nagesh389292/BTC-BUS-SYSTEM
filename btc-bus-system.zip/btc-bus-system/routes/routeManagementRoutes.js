// routes/routeManagmentRoutes.js
const express = require('express');
const router = express.Router();
const Route = require('../models/Route');

// Add a new route
router.post('/add', async (req, res) => {
  try {
    const { routeName, startPoint, endPoint, distance, time } = req.body;
    const newRoute = new Route({ routeName, startPoint, endPoint, distance, time });
    await newRoute.save();
    res.status(200).send('Route added successfully');
  } catch (err) {
    res.status(500).json({ message: 'Error adding route', error: err });
  }
});

// Get all routes
router.get('/', async (req, res) => {
  try {
    const routes = await Route.find();
    res.json(routes);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching routes', error: err });
  }
});

// Edit route
router.put('/edit/:id', async (req, res) => {
  try {
    const { routeName, startPoint, endPoint, distance, time } = req.body;
    const updatedRoute = await Route.findByIdAndUpdate(req.params.id, { routeName, startPoint, endPoint, distance, time }, { new: true });
    res.status(200).json(updatedRoute);
  } catch (err) {
    res.status(500).json({ message: 'Error updating route', error: err });
  }
});

// Delete route
router.delete('/delete/:id', async (req, res) => {
  try {
    await Route.findByIdAndDelete(req.params.id);
    res.status(200).send('Route deleted successfully');
  } catch (err) {
    res.status(500).json({ message: 'Error deleting route', error: err });
  }
});

module.exports = router;
