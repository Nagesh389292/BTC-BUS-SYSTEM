// routes/schedule.js
const express = require('express');
const router = express.Router();
const BusSchedule = require('../models/BusSchedule');

// Route to create a new bus schedule
router.post('/schedule', (req, res) => {
  const { busId, routeId, scheduledTime, driverId } = req.body;
  
  const newSchedule = new BusSchedule({
    busId,
    routeId,
    scheduledTime,
    driverId,
    status: 'Scheduled',
  });

  newSchedule.save()
    .then(schedule => res.status(201).json(schedule))
    .catch(err => res.status(400).json({ error: err.message }));
});

// Route to update a bus schedule (Reschedule)
router.put('/reschedule/:scheduleId', (req, res) => {
  const { scheduleId } = req.params;
  const { newTime, newRouteId } = req.body;

  BusSchedule.findByIdAndUpdate(scheduleId, { scheduledTime: newTime, routeId: newRouteId }, { new: true })
    .then(updatedSchedule => res.json(updatedSchedule))
    .catch(err => res.status(400).json({ error: err.message }));
});

module.exports = router;
