document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("linkedDutyForm");
  const dutyList = document.getElementById("dutyList");

  // Fetch all duties on page load
  fetch('/api/linked-duty')
    .then(res => res.json())
    .then(data => {
      displayDuties(data);
    });

  // Form submit
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const dutyData = {
      busNumber: document.getElementById("busNumber").value,
      startStop: document.getElementById("startStop").value,
      endStop: document.getElementById("endStop").value,
      startTime: document.getElementById("startTime").value,
      endTime: document.getElementById("endTime").value,
      driverName: document.getElementById("driverName").value
    };

    const res = await fetch('/api/linked-duty', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dutyData)
    });

    const result = await res.json();

    if (res.ok) {
      alert("✅ Duty Scheduled Successfully");
      form.reset();
      loadDuties();
    } else {
      alert("❌ Failed: " + result.message);
    }
  });

  function loadDuties() {
    fetch('/api/linked-duty')
      .then(res => res.json())
      .then(data => {
        displayDuties(data);
      });
  }

  function displayDuties(duties) {
    dutyList.innerHTML = "";
    duties.forEach(duty => {
      const li = document.createElement("li");
      li.textContent = `${duty.busNumber} | ${duty.startStop} → ${duty.endStop} | ${duty.startTime} - ${duty.endTime} | Driver: ${duty.driverName}`;
      dutyList.appendChild(li);
    });
  }
});
