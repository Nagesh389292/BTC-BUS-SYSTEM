document.getElementById('unlinkedDutyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const data = {
      dutyName: document.getElementById('dutyName').value,
      busNumber: document.getElementById('busNumber').value,
      driverName: document.getElementById('driverName').value,
      startTime: document.getElementById('startTime').value,
      endTime: document.getElementById('endTime').value
    };
  
    const res = await fetch('/api/unlinked-duty', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  
    const result = await res.json();
    alert(result.message);
    loadDuties();
  });
  
  async function loadDuties() {
    const res = await fetch('/api/unlinked-duty');
    const duties = await res.json();
  
    const list = document.getElementById('dutyList');
    list.innerHTML = '';
    duties.forEach(duty => {
      const li = document.createElement('li');
      li.textContent = `${duty.dutyName} | ${duty.busNumber} | ${duty.driverName} | ${duty.startTime} - ${duty.endTime}`;
      list.appendChild(li);
    });
  }
  
  loadDuties();
  