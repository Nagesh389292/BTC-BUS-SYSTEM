// JavaScript code in the trip planner page to fetch directions and display step-by-step instructions
document.getElementById("tripPlannerForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const startLocation = document.getElementById("startLocation").value;
  const endLocation = document.getElementById("endLocation").value;

  // Assuming you have coordinates for both locations. If you have addresses, use geocoding to get coordinates.
  const startCoordinates = "77.5946,12.9716"; // Example for Bangalore
  const endCoordinates = "77.6093,12.9313";   // Example for another Bangalore location

  const response = await fetch(
    `https://api.openrouteservice.org/v2/directions/driving-car?api_key=YOUR_API_KEY&start=${startCoordinates}&end=${endCoordinates}`
  );
  const data = await response.json();

  if (!data.features || data.features.length === 0) {
    alert("Error: Could not fetch directions");
    return;
  }

  const estimatedTime = data.features[0].properties.segments[0].duration; // Duration in seconds
  const distance = data.features[0].properties.segments[0].distance; // Distance in meters
  const directions = data.features[0].properties.segments[0].steps;

  // Display Estimated Time and Distance
  const timeInMinutes = Math.round(estimatedTime / 60); // Convert seconds to minutes
  document.getElementById("estimatedTime").textContent = `Estimated Time: ${timeInMinutes} minutes`;
  document.getElementById("distance").textContent = `Distance: ${Math.round(distance / 1000)} km`;

  // Display Step-by-Step Directions
  let directionsHtml = "<h3>Directions:</h3><ul>";
  directions.forEach(step => {
    directionsHtml += `<li>${step.instruction}</li>`;
  });
  directionsHtml += "</ul>";
  document.getElementById("directions").innerHTML = directionsHtml;
});
