// Initialize the map centered on Bangalore
const map = L.map("map").setView([12.9716, 77.5946], 12);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Function to simulate live bus location updates
let busMarker = null;

function startLiveTracking() {
  // Start tracking bus locations
  setInterval(() => {
    fetch('/api/bus-location')  // Fetch bus location from the API
      .then(res => res.json())
      .then(data => {
        const busLocation = data.location;

        // If a marker already exists, move it to the new bus location
        if (busMarker) {
          busMarker.setLatLng([busLocation.lat, busLocation.lng]);
        } else {
          // Create a new marker if not already created
          busMarker = L.marker([busLocation.lat, busLocation.lng]).addTo(map);
        }

        // Center the map on the bus location
        map.setView([busLocation.lat, busLocation.lng], 12);
      })
      .catch(err => console.error('Failed to fetch bus location', err));
  }, 5000); // Update every 5 seconds
}
