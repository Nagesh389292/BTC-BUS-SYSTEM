const mongoose = require('mongoose');

const unlinkedDutySchema = new mongoose.Schema({
  busNo: String,
  driverName: String,
  routeNo: String,
  from: String,
  to: String
});

module.exports = mongoose.model('UnlinkedDuty', unlinkedDutySchema);
