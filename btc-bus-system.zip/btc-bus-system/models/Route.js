// models/Route.js
const mongoose = require('mongoose');

const routeSchema = new mongoose.Schema({
  routeName: { type: String, required: true },
  startPoint: { type: String, required: true },
  endPoint: { type: String, required: true },
  distance: { type: String, required: true },
  time: { type: String, required: true },
});

const Route = mongoose.model('Route', routeSchema);
module.exports = Route;
