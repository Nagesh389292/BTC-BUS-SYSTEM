const mongoose = require('mongoose');

const BusScheduleSchema = new mongoose.Schema({
  busId: { type: String, required: true },
  routeId: { type: mongoose.Schema.Types.ObjectId, ref: 'Route', required: true },
  scheduledTime: { type: Date, required: true },
  driverName: { type: String, required: true }
});

const BusSchedule = mongoose.model('BusSchedule', BusScheduleSchema);

module.exports = BusSchedule;
