const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const session = require('express-session');
const bodyParser = require('body-parser');
const linkedDutyRoutes = require('./routes/linkedDutyRoutes');
const app = express();
const unlinkedDutyRoutes = require('./routes/unlinkedDutyRoutes');
const tripPlannerRoutes = require('./routes/tripPlannerRoutes');
const liveTrackingRoutes = require('./routes/liveTrackingRoutes');
app.use('/api/live-tracking', liveTrackingRoutes);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/api/linked-duty', linkedDutyRoutes);
app.use('/api/unlinked-duty', unlinkedDutyRoutes);
app.use('/api/trip-planner', tripPlannerRoutes);
app.use(session({
  secret: 'btc-bus-secret',
  resave: false,
  saveUninitialized: true
}));

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/btc-bus-system', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('✅ MongoDB Connected');
}).catch((err) => {
  console.error('❌ MongoDB Connection Error:', err);
});
app.post('/api/trip-planner/find-buses', async (req, res) => {
  try {
    const { from, to } = req.body;
    const buses = await LinkedDuty.find({ from, to });
    res.json(buses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});


// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Serve pages - only your requested pages and dashboard with buttons
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/linked-duty', (req, res) => res.sendFile(path.join(__dirname, 'public', 'linked-duty.html')));
app.get('/unlinked-duty', (req, res) => res.sendFile(path.join(__dirname, 'public', 'unlinked-duty.html')));
app.get('/trip-planner', (req, res) => res.sendFile(path.join(__dirname, 'public', 'trip-planner.html')));
app.get('/route-management', (req, res) => res.sendFile(path.join(__dirname, 'public', 'route-management.html')));
app.get('/live-tracking', (req, res) => res.sendFile(path.join(__dirname, 'public', 'live-tracking.html')));

// Start server
const PORT = 5000;
app.listen(PORT, () => console.log(`🚍 Server running on http://localhost:${PORT}`));
